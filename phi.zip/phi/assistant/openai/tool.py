from typing import Dict

CodeInterpreter: Dict[str, str] = {"type": "code_interpreter"}

Retrieval: Dict[str, str] = {"type": "retrieval"}
