from phi.assistant.openai.file.file import File
