from phi.embedder.base import Embedder
