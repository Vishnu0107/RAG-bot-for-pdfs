from phi.prompt.template import PromptTemplate
from phi.prompt.registry import PromptRegistry
