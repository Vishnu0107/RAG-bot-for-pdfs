class PromptUpdateException(Exception):
    pass


class PromptNotFoundException(Exception):
    pass
