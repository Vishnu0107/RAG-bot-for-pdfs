class InvalidToolCallException(Exception):
    pass
